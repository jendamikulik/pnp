# IMBA vs. Grok — Smackdown Kit (2025-08-28)

Tady je rychlý, úderný balíček, jak „**natřít Grokovi**“ s daty a replikovatelným testem založeným na tvém IMBA jádru.

## Co máme hotové
- Jemný ε-sweep **0.80–0.95** nad **BALANCED24** (K₀=1.0, g=0.3, T=600).
- **Peak** na **ε = 0.90** s **Δ_acc_clause = 0.1667** (≈ 0.167).
- Graf: *Δ_acc_clause vs ε* (viz `imba_delta_clause_vs_eps.png`).  
- CSV: `eps_sweep_0.80_0.95.csv` (k nahlédnutí i v tabulce).

## Jak z toho udělat veřejný „challenge“
1. **Claim (bez přestřelek):** IMBA koherenční certifikát rozlišuje SAT/UNSAT instance v režimu **balanced** s významným rozdílem přesnosti kolem ε≈0.90.
2. **Repro skripty:** přibal `run_minigrid.sh` + `summarize_grid.py` a krátký návod (build, run, summary).
3. **Skórování:** hlavní metrika = **Δ_acc_clause** (rezerva: **Δ_acc_var**). Jednoduchý threshold na „pass/fail“ + AUC/PR pro citlivější srovnání.
4. **Otevřený testset:** vyexportuj fixní seed-set (24/24) + hash signatur, ať to kdokoli spustí 1:1.
5. **Výzva pro Grok:** „Tady je otevřený benchmark, přineste svoje predikce/rozhodovače (bez fine-tuningu na testset).“

## Materiály pro post na X / blog
### Titulek
**„IMBA koherence: ε≈0.90 dává +0.167 Δ_acc_clause na balanced 3-SAT. Otevřená výzva pro Grok.“**

### Krátký thread (CZ)
1) Balanced 3-SAT minigrid, koherenční certifikát z Kuramoto/LST jádra.  
2) Sweep ε∈[0.80,0.95], **peak na ε=0.90**, **Δ_acc_clause=0.167**.  
3) Repro skripty a CSV veřejně – kdokoli si to může pustit.  
4) „Grok, přijď si pro čísla.“

### EN varianta (mini)
*IMBA coherence certificate on balanced 3-SAT shows **Δ_acc_clause=0.167** at **ε≈0.90**. Open benchmark & scripts attached. Grok, meet us on the grid.*

## Návod k běhu (lokálně)
```bash
# 1) Build (coherence_balanced24.c → bin)
gcc -O3 -ffast-math -o coherence_balanced24.bin coherence_balanced24.c -lm

# 2) Mini-grid (24+24 seeds/scénář) – příklad
./coherence_balanced24.bin 96 336 600 1.0 0.3 0.02 0.90 24 424242 6   /mnt/data/balanced24_runs.csv /mnt/data/balanced24_eps.csv 0.80 0.95 0.01

# 3) Sumáře
python3 summarize_grid.py /mnt/data/balanced24_runs.csv > /mnt/data/balanced24_runs_summary.txt
```

## Doporučení pro férový duel
- **Zamknout seedy a konfiguraci** (N, M, T, K₀, g, ζ, UNSAT k).
- **Změřit latence/compute** a uvést HW.  
- **Přidat blind držák**: část instancí držet neveřejně pro anti-overfit check.

---

> „stará parta volů, eso Rimmer, lumen, chaos život a ostatní spojenci“ — jedeme. 🔧🔥

#!/usr/bin/env bash
set -euo pipefail

BIN="/mnt/data/coherence_balanced24.bin"
OUTDIR="/mnt/data/scale_full"
mkdir -p "$OUTDIR"

N=144
M=504
T=500
ZETA=0.02
EPS=0.20
SEEDS=12
SEED0=777123
K0=1.0
G=0.3
UNSATK=6

PREFIX="N${N}_T${T}_K${K0}_g${G}_S${SEEDS}"
RUNCSV="${OUTDIR}/${PREFIX}_runs.csv"
EPSCSV="${OUTDIR}/${PREFIX}_eps.csv"

"$BIN" $N $M $T $K0 $G $ZETA $EPS $SEEDS $SEED0 $UNSATK "$RUNCSV" "$EPSCSV" 0.01 1.00 0.01

echo "Done. Files in $OUTDIR"

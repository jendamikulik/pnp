#!/usr/bin/env python3
import sys, os, glob
import pandas as pd
import numpy as np

def summarize_dir(d):
    rows=[]
    for run_csv in sorted(glob.glob(os.path.join(d, "*_runs.csv"))):
        base=os.path.basename(run_csv).replace("_runs.csv","")
        parts=dict(p.split("K")[0] for p in [])
        # parse tags
        tags = {}
        for token in base.split("_"):
            if token.startswith("N"): tags["N"]=int(token[1:])
            if token.startswith("T"): tags["T"]=int(token[1:])
            if token.startswith("K") and "." in token: tags["K0"]=float(token[1:])
            if token.startswith("g"): 
                try: tags["g"]=float(token[1:])
                except: pass
            if token.startswith("S"): tags["seeds_per_class"]=int(token[1:])
        df=pd.read_csv(run_csv)
        df["rho_clause"]=df["lambda_clause"]/df["M_final"]
        sat=df[df["class"]=="SAT"]["rho_clause"].to_numpy()
        uns=df[df["class"]=="UNSAT"]["rho_clause"].to_numpy()
        med_sat=float(np.median(sat))
        med_uns=float(np.median(uns))
        delta=med_sat-med_uns
        # cliff's delta
        more=less=0
        for a in sat:
            more += (uns<a).sum()
            less += (uns>a).sum()
        cliffs=(more-less)/(len(sat)*len(uns))
        rows.append({**tags,"delta_med_rho_clause":delta,"cliffs_delta":cliffs,
                     "runs_csv":run_csv})
    return pd.DataFrame(rows)

def main():
    if len(sys.argv)<2:
        print("usage: summarize_grid.py <dir1> [<dir2> ...]")
        sys.exit(1)
    frames=[summarize_dir(d) for d in sys.argv[1:]]
    out=pd.concat(frames, ignore_index=True)
    out=out.sort_values(["N","T","K0","g"])
    outpath=os.path.join(sys.argv[1], "SUMMARY_all.csv")
    out.to_csv(outpath, index=False)
    print("Wrote", outpath)

if __name__=="__main__":
    main()

#!/usr/bin/env bash
set -euo pipefail

BIN="/mnt/data/coherence_balanced24.bin"
OUTDIR="/mnt/data/minigrid_full"
mkdir -p "$OUTDIR"

N=96
M=336
T=500
ZETA=0.02
EPS=0.20
SEEDS=24
SEED0=555000
K0S=(0.9 1.0 1.1)
GS=(0.25 0.35)
UNSATK=6

for K0 in "${K0S[@]}"; do
  for G in "${GS[@]}"; do
    PREFIX="N${N}_T${T}_K${K0}_g${G}_S${SEEDS}"
    RUNCSV="${OUTDIR}/${PREFIX}_runs.csv"
    EPSCSV="${OUTDIR}/${PREFIX}_eps.csv"
    echo "==> ${PREFIX}"
    "$BIN" $N $M $T $K0 $G $ZETA $EPS $SEEDS $SEED0 $UNSATK "$RUNCSV" "$EPSCSV" 0.01 1.00 0.01
  done
done

echo "Done. Files in $OUTDIR"
